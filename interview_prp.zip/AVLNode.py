class AVLNode(BSTNode):
  """A node in an AVL."""
  
  def __init__(self, key):
    """Creates a node that will be inserted in an AVL.
  
    See __init__ in BSTNode."""
    BSTNode.__init__(self, key)
    self.height = 0

  def update_subtree_info(self):
    """Updates pre-computed fields such as the node's subtree height."""
    self.height = self._uncached_height()

  def _uncached_height(self):
    """Re-computes the node's height based on the children's heights."""
    return 1 + max((self.left and self.left.height) or -1,
                   (self.right and self.right.height) or -1)
    
  def check_ri(self):
    """Checks the AVL representation invariant around this node.
    
    Raises an exception if the RI is violated.
    """
    if self.height != self._uncached_height():
      raise RuntimeError("AVL RI violated by node height")
    if abs(AVL._height(self.left) - AVL._height(self.right)) > 1:
      raise RuntimeError("AVL RI violated by unbalanced children heights")
    BSTNode.check_ri(self)