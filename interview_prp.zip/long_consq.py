'''
[[0,1,2,3],
[16,8,9,4],
[11,13,12,5],
[17,18,7,6]]
'''
def are_neighbours(n1,n2):
    if (n1 == None) or (n2 == None):
       return False
    else:
       n1=n1[1]
       return ((n1[0]==n2[0] and abs(n2[1]-n1[1]) == 1) or (n1[1]==n2[1] and abs(n2[0]-n1[0]) == 1))
def consecutive(n1,n2):
    if (n1 == None) or (n2 == None):
       return False
    else:
       return n2-n1[0]==1
def generate_list(m):
   l={}
   for r in range(len(m)):
       for c in range(len(m[r])):
           l[m[r][c]] = (r,c)
   return l         
  
def find_longest(m):
    l = generate_list(m)  
    longest = 0
    temp_long = 1
    last = None
    for i in l:
        if are_neighbours(last,l[i]) and consecutive(last,i):
           temp_long += 1
        else:
           temp_long = 1
        if temp_long>longest:
           longest = temp_long
        last = (i,l[i])
    return longest
    

if __name__=='__main__':
    m = [[0,1,2,3],[16,8,9,4],[11,13,12,5],[17,18,7,6]]
    print find_longest(m)
  
