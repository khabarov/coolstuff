#List (really resizeable array (table doubling) of references to other objects)
#resizeable/dynamic, random access, can store values of diffferent types
#access: O(1) if index is known
#search: O(N)
#insert: O(1) #(at end, O(N) everywhere else) due to amortized time
#delete: O(1) #(at end, O(N) everywhere else) due to amortized time
#space:  O(N)
def list():
	list=[1,2,3] 
	list[0]
	list[-1]
	2 in list
	5 in list
        list+=4
        list.append(5)
	list.remove(0)
	list.append([4,5,5])
	list.pop(1)
	len(list)

#Tuple
#immutable/fixed size, random access, can store values of different types
def tuple():
	tuple=('this',2,3.83)
	tuple[0]
	tuple[-1]
	tuple.append(77) # can't do this
	tuple.remove('this') # can't do this
	len(tuple)
#Set
#unordered collection with no duplicate values
def set():
	a = set([1,1,2,3])
	b = set((1,4,4,5])
	a                                  # unique letters in a
	a - b                              # letters in a but not in b
	a | b                              # letters in either a or b
	a & b                              # letters in both a and b
	a ^ b                              # letters in a or b but not both
#Strings
#Just like lists
def string():
	s = 'hi there'
	s[0]
	s[0:2]
	s[2:]
	s[::-1] # reverse a strings
	
#Linked List
#List made of nodes where each node has a value and pointer to the next or/and previuos node fields
#Sequential access only/ no random access
#access: O(N) need to scan to find my node
#search: O(N)
#insert: O(N) need to scan to find the place where to insert
#delete: O(N) need to scan to find which to node to delete 
#space:  O(N) 
class Node():
    def __init__(self,key=None,next=None):
	self.key = key
	self.next = next
	#self.prev = prev

#creating a singly linked list 1->2->3->4->5->None
#1
head = Node(5)
for i in range(4,0,-1):
	head = Node(i,head)

def find(ll,key):
	found = False
	while ll is not None and ll.key is not key:
		ll = ll.next
	if ll.key is key:
		found = True
	return found
def insert(ll,key,pos=None):
	# is pos is None insert at the end
	if ll is None:
			return Node(key)
	if pos is None:
		while ll.next is not None:
			ll = ll.next
		ll.next = Node(key)
	else:
		count = 0
		while ll.next is not None and count+1 is not pos:
			ll = ll.next
		oldNext = ll.next
		newNode = Node(key)
		ll.next = newNode
		newNode.next = oldNext
					
def delete(ll,key):
	if ll is None:
		return "Linked List is empty"
	while ll.next is not None and ll.next.key is not key:
		ll = ll.next
	if ll.next is None:
		return "Key is not in linked list"
	ll.next = ll.next.next
	
	
#creating a doubly linked list None<-1-><-2-><-3-><-4-><-5->None
#1
tail = Node(5)
head = tail
for i in range(4,0,-1):
	head = Node(i,head)
	tail.prev = head
	tail = head




#Stack
#Using singly-linked list
#First in, last out (FILO)
#Push, Pop, Peek are in O(1)

class Node():
       def __init__(self,key=None,next=None):
	  self.key = key
	  self.next = next
	  #self.prev = prev

class Stack():
   def __init__(self):
      self.head = None
      self.size = 0
   def push(self,value):
      self.head = Node(value,self.head)
      self.size+=1
      return 'pushed', self.head.key
   def pop(self):
      if self.head is None:
	 return 'Stack is empty'
      popped = self.head.key
      self.head = self.head.next
      self.size-=1
      return 'popped', popped
   def peek(self):
      if self.head is None:
	 return None
      return self.head.key
   def size(self):
      return self.size

#Queue
#First in, first out (FIFO)
#Using doubly-linked list
#Enqueue, Dequeue, Peek are in O(1)


class Node():
       def __init__(self,key=None,next=None,prev=None):
	  self.key = key
	  self.next = next
	  self.prev = prev

class Queue():
   def __init__(self):
      self.head = None
      self.tail = None
      self.size = 0
   def enqueue(self,value):
      if self.head is None and self.tail is None:    
       	 self.head = Node(value)
         self.tail = self.head
      else:
         self.head = Node(value,self.head)
	 self.head.next.prev = self.head
      self.size+=1
      return 'enqueued', self.head.key
   def dequeue(self):
       if self.head is None and self.tail is None:
          return 'Queue is empty'
       key = self.tail.key
       self.tail = self.tail.prev
       if self.tail is None:
         self.head = None
       else:
         self.tail.next = None
       self.size-=1
       return key
   def peek(self):
       if self.tail is None:
          return 'Queue is empty'
       return self.tail.key 	
   def size(self):
       return self.size


#Tree
#Terms: root, parent, child, leaves, edges
# Depth (of a node): length (#edges) from the root to this node
# Height (of a node): length (# edges) of the longest downward path to a leaf
# Height (of a tree): height of the tree's root node
#Nodes that contain data and pointers to child nodes and/or parent nodes
#Top node is a root node
#Bottom nodes are leaves (i.e. no children)
#Represents heirarchical or ordered set of data elements
class TreeNode():
       def __init__(self,value=None,children=None):
	  self.value = value
	  self.children = children

#Binary tree
#A tree where each node has at most two children

#Binary search tree
#A binary tree where for each node, the value of its left child is less than its #own and the value of its right child is greater than its own 
#Each BSTNode has:
#key, left and right child pointers and parent pointer
#Supported operations: insert/delete/search, min/max, successor/predecessor


#Binary balanced/self-balancing search tree
#A BST that maintains height of O(lg n)
#All operations run in O(lg n) time
#AVL:
#For every node, heights of left & right subtree to differ by at most (+/-)1
#each node stores its height
#Supported operations: insert/delete/search


#Depth First Search 
#Pre order
def pre(node):
    if (node == None): 
	return
    else:    
    	print(node.key)
    pre(node.left)
    pre(node.right)

#In order
def in(node):
    if (node == None): return    
    in(node.left)
    print(node.key)
    in(node.right)

#Post order
def post(node):
    if (node == None): return    
    post(node.left)
    post(node.right)
    print(node.key)


#Breadth First Search
#Level(depth) Order

#Queue based
def bfs(node)
  q = Queue()
  q.enqueue(node)
  while (not q.isEmpty()):
    node = q.dequeue()
    print(node.key)
    if (node.left is not None)
      q.enqueue(node.left)
    if (node.right is not null)
      q.enqueue(node.right)

#Iterative deepening based
def printLevels(root):
    h = height(root)
    for i in range(1, h+1): #for each level
        printLevel(root, i)

def printLevel(root , level):
    if root is None:
        return
    if level == 1:
        print(root.key)
    elif level > 1 :
        printLevel(root.left, level-1)
        printLevel(root.right, level-1)

#get tree height
def height(node):
    if node is None:
        return -1
    else :
        # Compute the height of each subtree 
        lheight = height(node.left)
        rheight = height(node.right)
        return max(lheight,rheight)+1


class Node:
    def __init__(self, key):
        self.key = key 
        self.left = None
        self.right = None


#Graph
#Edges and vertices
#An ADT that is used to model relationships between objects
#Directed(as ordered pairs) and undirected(as unordered pairs)
#Weigheted(edges have weights), unweights(no edge weights)
#Connected(strongly)(can visit all vertices from all other vertices), disconnected(some vertices are unreachable from some vertices)

#3 basic ways to represent a graph in memory:
#Objects and pointers
#|V+E| space
#adjacency matrix
#|V^2| space, O(1) to check for an edge
#and adjacency list (hashtable really)
#|V+E| space, O(length of list) to check for an edge

#Graph traversal (visiting every vertex)
#Breadth First Search
def bfs(s,adj):
    level = {s:0} #what level we discovered each vertex
    parent = {s: None} #for getting shortest path
    i = 1
    # previous level, i-1
    while frontier:
         next = []
             for u in frontier:
                 for v in adj[u]
                     if v not in level:
                        level[v] = i
                        parent[v] = u
                        next.append(v)
         frontier = next
         i += 1
     return parent
#Going over all vertices and their parent vertices
#to get all single-source shortest paths from the source to all other vertices
def sssp(parents):
    sssp = []
    for p in parents:
        sp = []
        sp.append(p)
        par = parents[p]
        while par is not None:
              sp.append(par)
              par = parents[par]
        sssp.append(sp)
     return sssp
#Runs in O(|V|+|E|)
#Level of each vertex indicates the distance from the source vertex
#Can be used for getting single-source shortest paths on unweighted graph(on unweighted only because in weighted graph weights affect paths you take)
#Following the parent of each vertex gives us the shortext path from the source vertex to all other vertices


#Depth First Search
parents = {s:None}
finished = []
def dfs_visit(s,adj):
    for v in adj[s]:
        if v not in parents:
           parents[v]=s
           dfs_visit(v,adj)
    finished.append(s)
def topological _sort():
    return finished.reverse()
#Set the starting vertex
def dfs(V,adj):
    visited = {}
    for s in V:
        if s not in visited:
           visited[s] = True
           dfs_visit(s,adj)

#Runs in O(|V|+|E|) time
#Can be used for topological sort(e.g. course prerequisites--what is the right order to take courses based on the prerequsites) and cycle detection(back edges)


    







	




