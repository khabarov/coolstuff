'''
h*2-1
h+1
   
   0 1 2 3 4
   0 1 2 3 4
0-3
1-2
2-1
3 0 
4 1
5 2
6 3
(h-1)+hd
'''

#columns matrix
columns = []
#tree height
h = 0


#Node class
class Node:
    def __init__(self, key):
        self.key = key 
        self.left = None
        self.right = None

#get tree height
def height(node):
    if node is None:
        return -1
    else :
        # Compute the height of each subtree 
        lheight = height(node.left)
        rheight = height(node.right)
        return max(lheight,rheight)+1


#Pre order traversal
def pre(node,height,hd):
    if (node == None): return    
    if columns[(h-1)+hd][height] is not None:
    	columns[(h-1)+hd][height] = (columns[(h-1)+hd][height],node.key)
    else:
        columns[(h-1)+hd][height] = node.key
    pre(node.left,height-1,hd-1)
    pre(node.right,height-1,hd+1)

#Output tree in columns from the columns matrix
def print_columns(columns):
    output = []
    for r in columns:
        l = []
        for c in r:
            if c is not None:
               if type(c) is not tuple:
                  l.append(c)
               else:
                  l.extend(c)
        output.extend(l[::-1])
    print output
        
if __name__ == "__main__":
	root = Node(6)
	root.left = Node(3)
	root.right = Node(4)
	root.left.left = Node(5)
	root.left.left.left = Node(9)
	root.left.right = Node(1)
	root.right.right = Node(0)
	root.right.right.left = Node(8)
	root.left.left.right = Node(2)
	root.left.left.right.right = Node(7)

        h = height(root)
        if h == 0:
   	    print root.key
	else:
            #list comprehension (i.e. creating a 2d matrix
            columns = [[None for c in range(h+1)] for r in range(h*2-1)]
   	    pre(root,h,0) 
            print_columns(columns)


#######

'''
Implement an algorithm to determine if a string has all unique characters. What
if you cannot use additional data structures?
'''
def unique(s):
    if len(s) == 0 or len(s)>256:
	return False
    if len(s) == 1:
        return True
    chars = {}
    for c in s:
        if c in chars:
           return False
        else:
           chars[c] = 1
    return True     
'''
Implement a function void reverse(char* str) in C or C++ which reverses a null-
terminated string.
'''
def reverse(s):
    if len(s) == 0:
       return "Cannot reverse empty string"
    if len(s) == 1:
       return s
    s = list(s)
    i = 0
    j = len(s)-1
    while j>i:
          s[i],s[j] = s[j],s[i]
          i+=1
          j-=1
    s = "".join(s)
    return s

'''
Given two strings, write a method to decide if one is a permutation of the other.
'''
def isPermutation(s1,s2):
    if len(s1) == 0 or len(s2) == 0:
       return False
    if len(s1) == 1 and len(s2) == 1 and s1==s2:
       return True
    if len(s1) is not len(s2):
       return False
    chars = {}
    for c in s1:
        if c in chars:
           chars[c] += 1
        else:
           chars[c] = 1
    for c in s2:
        if c not in chars: return False
        if c in chars:
           if chars[c] == 0: return False
           chars[c] -= 1
    return True

'''
Implement a method to perform basic string compression using the counts
of repeated characters. For example, the string aabcccccaaa would become
a2blc5a3. If the "compressed" string would not become smaller than the orig-
inal string, your method should return the original string.
'''

def compress(s):
    if len(s) == 0:
       return "Cannot compress emptry string"
    comp_s = ""
    count = 0
    prev = s[0]
    for i in xrange(len(s)):
        if s[i] == prev:
            count += 1
            if i == len(s)-1:
               comp_s += (s[i])
               comp_s += (str(count)) 
        else:
               comp_s += (prev)
               comp_s += (str(count))
               count = 1
               if i == len(s)-1:
               	  comp_s += (s[i])
               	  comp_s += (str(count)) 
        prev = s[i]
        if len(comp_s) >= len(s):
           return s 
    return comp_s
              
        







        



