lists = [[87, 79, 66, 65, 55, 44, 38, 20, 9, 8], [72, 68]]
currentPos = [0]*len(lists)
maxVal = lists[0][0]
sortedList = []
proceed=True
while proceed:
      proceed=False
      pos = 0
      maxVal = None
      for i in xrange(len(currentPos)):
          if currentPos[i]<len(lists[i]): 
              if lists[i][currentPos[i]]>=maxVal:
                  maxVal = lists[i][currentPos[i]]
                  pos = i
              proceed=True
      if proceed:          
         sortedList.append(maxVal)
         currentPos[pos]+=1
print sortedList
