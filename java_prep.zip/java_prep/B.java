class B extends A{
	public void m3(){
	 	System.out.println("B's Method 3");
	}

	public void m2(){
	 	System.out.println("B's Method 2");
	}
	

	public static void main(String[] args){
		A a = new B();
		a.m3();
                a.m2();
	}
}
