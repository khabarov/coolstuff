class A{
	public void m3(){
	 	System.out.println("A's Method 3");
	}

}
