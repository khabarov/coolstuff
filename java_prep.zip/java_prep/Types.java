public class Types {

	public static void main(String[] args) {

        String[] stringArray = new String[20];
        System.out.println(stringArray[0]);

        Integer i1 = new Integer(7);
	Integer i2 = new Integer(7);
	int i3 = 7;
	System.out.println(i1==i3);
	System.out.println(i1==i2);
	System.out.println(i1.equals(i2));

        }

}
