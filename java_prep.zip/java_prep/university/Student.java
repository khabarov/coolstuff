package university;

// 2 Oct: We began working on this new subclass.

public class Student extends Person {
	private String studentNum;
	// 2 October: I added this after class, and made it public in order
	// to demonstrate "shadowing".
	public String motto;

	// We generated this constructor automatically,
	// and saw that it used super to call the appropriate
	// constructor from the parent class. This avoids
	// duplicate code.
	public Student(String[] name, String dob, String gender, String studentNum) {
		super(name, dob, gender);
		this.studentNum = studentNum;
		// 2 October: I added this after class.
		this.motto = "Free pizza!!";
	}

	// We decided not to have a setter for this attribute,
	// since a student's student number should not change over time.
	public String getStudentNum() {
		return studentNum;
	}

	// We overrode the toString from class Person.
	// Again, we avoided duplicating code by calling the
	// method in the parent class to do the parent-related
	// parts of the job.
	@Override
	public String toString() {
		return super.toString() + " , " + this.studentNum;
	}

}
