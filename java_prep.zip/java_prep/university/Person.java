// Aside: some useful Eclipse things we used:
// Help -> search box
// Source -> Toggle Comment
// Source -> Format

package university;

public class Person {
	private String[] name;
	private String dob;
	private String gender;
	// 2 October: I added this after class, and made it public in order
	// to demonstrate "shadowing".
	public String motto;

	// We generated these constructors automatically using
	// Source -> Generate Constructor Using Fields
	public Person(String[] name, String dob, String gender) {
		// super(); We'll explain this later.
		this.name = name;
		this.dob = dob;
		this.gender = gender;
		// 2 October: I added this after class.
		this.motto = "Live long and prosper";
	}

	public Person(String[] name) {
		super();
		this.name = name;
	}

	// We made this constructor by typing it.
	// public Person(String[] name, String dob, String gender) {
	// this.name = name;
	// this.dob = dob;
	// this.gender = gender;
	// }

	// 2 Oct: We wrote this getter/setter pair by hand.
	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	// 2 Oct: We generated these getter/setter pairs automatically using
	// Source -> Generate Getters and Setters
	public String[] getName() {
		return name;
	}

	public void setName(String[] name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	// 2 Oct: We overrode the toString inherited from Object.
	// Adding the @Override annotation allows Eclipse to warn
	// us if we think we are overriding, but we actually aren't,
	// e.g., due to a typo in the method name. This can save us
	// from some nasty bugs.
	@Override
	public String toString() {
		String result = new String("");
		for (String n : this.name) {
			result = result + n + " ";
		}
		result += this.dob;
		this.name[0] = "Bob";
		// Note the syntax of an if-statement.
		// For more, see:
		// http://docs.oracle.com/javase/tutorial/java/nutsandbolts/if.html
		if (this.gender.equals("M")) {
			result += ", male";
		} else {
			result += ", female";
		}
		return result;
	}
}
