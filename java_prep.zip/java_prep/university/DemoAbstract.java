package university;

public class DemoAbstract {

    /** Demonstrates more overriding and polymorphism. */
    public static void main(String[] args) {

        // We cannot instantiate an abstract class.
        // This results in a compilation error.
        // Grade g = new Grade();

        // Our two subclasses of Grade define bodies for all the abstract
        // methods in Grade; there is only one: double gpa()
        // Therefore, they need not be declared abstract.
        // Therefore, they can be instantiated.
        LetterGrade lgA = new LetterGrade("A");
        LetterGrade lgB = new LetterGrade("B");
        NumericGrade ng100 = new NumericGrade(100);
        NumericGrade ng42 = new NumericGrade(42);

        // Here we use the method that was abstract in Grade, and defined
        // in the two subclasses.
        System.out.println(lgA.gpa());
        System.out.println(lgB.gpa());
        System.out.println(ng100.gpa());
        System.out.println(ng42.gpa());

        // More polymorphism.
        Grade myGrade = lgA;
        Grade[] grades = { lgA, lgB, ng100, ng42 };

        for (Grade g : grades) {
            // What method is implicitly called here?
            // What thing is it that is polymorphic (taking "many forms")?
            System.out.println(g);
        }
    }

}
