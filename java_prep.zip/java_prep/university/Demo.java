package university;

public class Demo {
	public static void main(String[] args){
		// The line below worked fine at first, even though we had 
		// not defined any constructor, because Java defined a
		// no-argument constructor by default.  But later when we 
		// added a constructor of our own, the line didn't work.
		// If you define any constructor, Java will no longer define
		// a no-argument constructor for you.
		// Person diane = new Person();
		
		String[] name = new String[] {"Diane", "Lynn", "Horton"};
		Person diane = new Person(name, "1999 Jan 31", "F");
		System.out.println(diane);
		
		// 2 Oct: We observed that this is not allowed, 
		// because dob is a private instance variable.
		//diane.dob = "xxxx";
		
		// 2 Oct: But we can access the private instance variables
		// using our setters and getters.
		diane.setDob("sldkfjsdlksdjf");
		
		// 2 Oct: We added a subclass and constructed an instance
		// of it.
		Student catherine = new Student(
				new String[] {"Cat", "Fairgrieve"},
				"13 Feb",
				"F",
				"12343535"
				);
		System.out.println(catherine);
	}
	
}
