package university;

public class DemoInheritance {
	
	public static void main(String[] args) {

		//demoInheritance();
		demoAliasing();
	}

	/** Demonstrates overriding and shadowing. */
	
	public static void demoInheritance() {

		// ==== Method overriding ====

		String[] harryName = new String[] {"Harry", "Potter"};
		Person harry = new Person(harryName, "31 July, 1980", "M");
		
		String[] hermioneName = new String[] {"Hermione", "Granger"};
		Student hermione = new Student(hermioneName, "19 September 1979", 
				"F", "0444555666");

		// Runs toString() from class ___________.
		System.out.println(harry);

		// Runs toString() from class ___________.
		System.out.println(hermione);

		// ======== Variable shadowing and the influence of casting ========

		// After lecture, I added a String instance variable named motto to
		// the Person class and to the Student class. Let's use it
		// to experiment with how instance variables are different
		// from methods.
		
		// Prints motto from class ____________.
		System.out.println(harry.motto);
		
		// Prints motto from class ____________.
		System.out.println(hermione.motto);

		// Although hermione refers to a Student object, it also has a Person
		// part of it.  The variable hermione itself has type Student, but
		// we can "cast" it as a Person by doing this:
		//      (Person) hermione
		// The type of that expression is Person, rather than student.
		
		// By using casting, we can influence which variable we get
		// when we refer to "motto".

		// Prints motto from class ____________.
		System.out.println(((Person) hermione).motto);
		
		// ======== How does casting influence method calls? ========
		
		// Runs toString() from class ___________.
		System.out.println(((Person) hermione).toString());
	}

	/** Demonstrates some aspects of aliasing.  We'll cover this
	 * in class next week.  You can do Exercise 1 right now.  */
	
	public static void demoAliasing() {

		// Exercise 1: Trace this in detail, drawing the memory model.
		// Predict the output.
		String[] jenName = { "Jen", "C" };
		Person jen = new Person(jenName, "21012000", "F");
		System.out.println(jen);
		//jenName[0] = "Bob";
		System.out.println(jenName[0]);

		// Exercise 2: After we make a first set of code changes in lecture,
		// trace the same code and predict again.

		// Exercise 3: With that changed version of the classes,
		// what does this new code do:
		// <Code to be provided>

		// Exercise 4: After we make a second set of code changes in lecture,
		// trace and predict the above code again.
	}
}
