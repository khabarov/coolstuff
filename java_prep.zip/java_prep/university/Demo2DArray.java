package university;

public class Demo2DArray {

    private static int numberOfBicycles;

    public static void main(String[] args) {

        // A 3-by-4 array.
        int[][] table = new int[3][4];
        System.out.println(table[1][2]);

        // Notice that we didn't put any values in table, yet the code ran.
        // For local variables, that won't work!
        // A local variable must be explicitly given a value before it is
        // used. So this code won't compile:
         System.out.println("numberOfBicycles is " + Demo2DArray.numberOfBicycles);
        // In contrast, each class variable, instance variable, or
        // array component is initialized with a default value when it is
        // created. Default values are generally 0, false, or null
        // (for objects).

        // A two-dimensional array is really an array whose elements are
        // themselves arrays. This means that they don't have to be all
        // of the same size. When length varies, we sometimes use the term
        // "jagged" or "ragged" array.
        // Here's an array with 3 elements, of length 4, 2, and 3,
        // respectively.
        int[][] jagged = new int[3][];
        jagged[0] = new int[4];
        jagged[1] = new int[2];
        jagged[2] = new int[3];

        for (int r = 0; r < jagged.length; r++) {
            System.out.println(jagged[r].length);
        }
    }
}
