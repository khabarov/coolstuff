#!/usr/bin/python
import math, random, Queue, sys

# backtracking - depth first search for a solution
# prune the search space when an infeasible state arises

# real 0/1-Knapsack
# Input: I and array of (w,v) positive number pairs, positive capacity k
# Problem: Find subset S of range(len(I)) such that 
#          sum([I[i][0] for i in S]) <= k and 
#          sum([I[i][1] for i in S]) is maximal

# Depth First Search for a solution
def r01KnapsackBacktrack(I, k, j=0, S=[]):
	weight = sum([I[i][0] for i in S])
	value  = sum([I[i][1] for i in S])

	if weight> k: 
		# print "pruning room"
		return ([],0,0) # (set, weight, value)

	if weight== k: 
		# print "pruning = k"
		return (S, weight, value) 

	if j>=len(I): return (S, weight, value) # leaves

	# either we use I[j] or not
	T1 = S[:]
	T1.append(j) # use weight j
	(T1, weight1, value1) = r01KnapsackBacktrack(I,k,j+1,T1)

	T0 = S[:]
	# T.append(j) # don't use weight j
	(T0, weight0, value0) = r01KnapsackBacktrack(I,k,j+1,T0)

	if value1>value0: return (T1, weight1, value1)
	else: return (T0, weight0, value0)

# Fractional Knapsack
# Input: I and array of (w,v) positive number pairs, positive capacity k
# Problem: As in r01Knapsack, except, now it is possible to 
#          take a weight, or part of a weight. If fraction f, with 0<=f<=1 of 
#          weight w is taken (f*w), then its value is f*v.
def greedyKnapsack(I, k, fractional=False):
	# make sure that I is sorted in order of value
	I = sorted(I,reverse = True, key = lambda x: float(x[1])/float(x[0]))
	S = []
	total_weight = 0
	total_value = 0
	current = 0 
	while True:
		if current>=len(I): break

		(weight, value) = I[current]
		if total_weight+weight<=k:
			total_weight = total_weight + weight
			total_value  = total_value  + value
			current = current + 1
		elif fractional:
			# take a fraction of the remaining weight
			weight_room = k - total_weight
			total_value = total_value + (weight_room/weight)*value
			total_weight = k
			break
		else:
			break
		
	return (total_weight, total_value)

# Branch and bound: Breadth first search for a solution
def r01KnapsackBAB(I, k, percent=100):
	(best_S, best_weight, best_value) = ([], 0,0) # (set, weight, value)
	queue = Queue.Queue()
	queue.put(([], -1)) # (partial subset, considered 0,...,this)
	while True:
		if queue.empty(): break
		(S, j) = queue.get()

		weight = sum([I[i][0] for i in S])
		value  = sum([I[i][1] for i in S])

		if value > best_value:
			(best_S, best_weight, best_value) = (S[:], weight,value) 

		# if a leaf no need to consider extensions
		if j == len(I)-1: continue

		j = j + 1

		# consider using item j
		weight_room = k - weight - I[j][0]
		if weight_room>=0:
			(bound_weight, bound_value) = greedyKnapsack(I[j+1:],weight_room, fractional=True)
			if bound_value + value + I[j][1] >= best_value:
				T = S[:]
				T.append(j)
				queue.put((T,j))
			# else: print "cutting branch bound"
		# else: print " cutting branch room"
					
		# consider not using item j
		weight_room = k - weight 
		if weight_room>=0:
			(bound_weight, bound_value) = greedyKnapsack(I[j+1:],weight_room, fractional=True)
			if bound_value + value >= best_value:
				T = S[:]
				queue.put((T,j))
			# else: print "cutting branch bound"
		# else: print " cutting branch room"

	return (best_S, best_weight, best_value)
	
if __name__ == '__main__':

	print "basic code"
	for n in range(10,30):
		I = [ (math.sqrt(random.randrange(1,n)), random.randrange(2,4*n)) for i in range(1,n) ]
		print r01KnapsackBacktrack(I, n)
		print r01KnapsackBAB(I, n)

	'''
	print "Question 3"
        random.seed(373)
	n = 40 
	I = [ (math.sqrt(random.randrange(1,n)), random.randrange(2,4*n)) for i in range(1,n) ]
	for percent in range(60,101):
		print percent, r01KnapsackBAB(I, n, percent)

	print "Question 4"
	percent = 98
	for n in range(40,200):
        	random.seed(373)
        	I = [ (math.sqrt(random.randrange(1,n)), random.randrange(2,4*n)) for i in range(1,n) ]
		# print I
		print n, r01KnapsackBAB(I, n, percent)
	'''
